/*!@license
* Infragistics.Web.ClientUI Splitter localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.Splitter=$.ig.Splitter||{};$.ig.locale=$.ig.locale||{};$.ig.locale.en=$.ig.locale.en||{};$.ig.locale.en.Splitter={errorPanels:"The number of panels have to be no more than two.",errorSettingOption:"Error setting option."};$.ig.Splitter.locale=$.ig.Splitter.locale||$.ig.locale.en.Splitter;return $.ig.locale.en.Splitter});