/*!@license
* Infragistics.Web.ClientUI Radial Menu localization resources 24.1.20241.24
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ja=$.ig.locale.ja||{};$.ig.RadialMenu=$.ig.RadialMenu||{};$.ig.locale.ja.RadialMenu={invalidItemKey:"Žw’è‚µ‚½€–ÚƒL[‚Í–³Œø‚Å‚·B",notSupported:"ƒTƒ|[ƒg‚³‚ê‚Ü‚¹‚ñB"};$.ig.RadialMenu.locale=$.ig.RadialMenu.locale||$.ig.locale.ja.RadialMenu;return $.ig.locale.ja.RadialMenu});