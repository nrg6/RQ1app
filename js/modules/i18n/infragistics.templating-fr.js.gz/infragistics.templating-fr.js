/*!@license
* Infragistics.Web.ClientUI templating localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.fr=$.ig.locale.fr||{};$.ig.Templating=$.ig.Templating||{};$.ig.locale.fr.Templating={undefinedArgument:"Une erreur s'est produite pendant la récupération de la propriété de la source de données : "};$.ig.Templating.locale=$.ig.Templating.locale||$.ig.locale.fr.Templating;return $.ig.locale.fr.Templating});