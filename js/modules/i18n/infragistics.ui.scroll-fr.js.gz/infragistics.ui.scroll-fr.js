/*!@license
* Infragistics.Web.ClientUI Scroll localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.Scroll=$.ig.Scroll||{};$.ig.locale=$.ig.locale||{};$.ig.locale.fr=$.ig.locale.fr||{};$.ig.locale.fr.Scroll={errorNoElementLink:"L'élément en cours de liaison n'existe pas.",errorNoScrollbarLink:"L'élément de la barre de défilement en cours de liaison n'existe pas."};$.ig.Scroll.locale=$.ig.Scroll.locale||$.ig.locale.fr.Scroll;return $.ig.locale.fr.Scroll});