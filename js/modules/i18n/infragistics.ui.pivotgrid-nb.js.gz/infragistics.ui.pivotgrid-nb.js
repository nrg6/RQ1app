/*!@license
* Infragistics.Web.ClientUI Pivot Grid localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.PivotGrid=$.ig.PivotGrid||{};$.ig.locale=$.ig.locale||{};$.ig.locale.nb=$.ig.locale.nb||{};$.ig.locale.nb.PivotGrid={filtersHeader:"Slipp filterfelt her",measuresHeader:"Slipp dataelementer her",rowsHeader:"Slipp radfelt her",columnsHeader:"Slipp kolonnefelt her",disabledFiltersHeader:"Filtrer felt",disabledMeasuresHeader:"Dataelementer",disabledRowsHeader:"Radfelt",disabledColumnsHeader:"Kolonnefelt",noSuchAxis:"Ingen slik akse"};$.ig.PivotGrid.locale=$.ig.PivotGrid.locale||$.ig.locale.nb.PivotGrid;return $.ig.locale.nb.PivotGrid});