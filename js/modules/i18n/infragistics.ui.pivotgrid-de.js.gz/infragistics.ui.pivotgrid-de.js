/*!@license
* Infragistics.Web.ClientUI Pivot Grid localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.PivotGrid=$.ig.PivotGrid||{};$.ig.locale=$.ig.locale||{};$.ig.locale.de=$.ig.locale.de||{};$.ig.locale.de.PivotGrid={filtersHeader:"Filterfelder hier ablegen",measuresHeader:"Datenfelder hierher ziehen",rowsHeader:"Zeilenfelder hierher ziehen",columnsHeader:"Spaltenfelder hierher ziehen",disabledFiltersHeader:"Filterfelder",disabledMeasuresHeader:"Datenelemente",disabledRowsHeader:"Zeilenfelder",disabledColumnsHeader:"Spaltenfelder",noSuchAxis:"Keine solche Achse"};$.ig.PivotGrid.locale=$.ig.PivotGrid.locale||$.ig.locale.de.PivotGrid;return $.ig.locale.de.PivotGrid});