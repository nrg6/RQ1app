/*!@license
* Infragistics.Web.ClientUI shared localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale["zh-Hans"]=$.ig.locale["zh-Hans"]||{};$.ig.SharedLocale=$.ig.SharedLocale||{};$.ig.locale["zh-Hans"].SharedLocale={};$.ig.SharedLocale.locale=$.ig.SharedLocale.locale||$.ig.locale["zh-Hans"].SharedLocale;return $.ig.locale["zh-Hans"].SharedLocale});