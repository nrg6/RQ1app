/*!@license
* Infragistics.Web.ClientUI Linear Gauge localization resources 24.1.20241.24
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.pl=$.ig.locale.pl||{};$.ig.LinearGauge=$.ig.LinearGauge||{};$.ig.locale.pl.LinearGauge={rangeNameMissing:"Brak nazwy zakresu dla zakresu: "};$.ig.LinearGauge.locale=$.ig.LinearGauge.locale||$.ig.locale.pl.LinearGauge;return $.ig.locale.pl.LinearGauge});