/*!@license
* Infragistics.Web.ClientUI Notifier localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.bg=$.ig.locale.bg||{};$.ig.Notifier=$.ig.Notifier||{};$.ig.locale.bg.Notifier={successMsg:"Успех",errorMsg:"Грешка",warningMsg:"Внимание",infoMsg:"Информация",notSupportedState:"Неподдържано състояние на нотификациите! Използвайте някое от поддържаните състояния 'success', 'info', 'warning', 'error’.",notSupportedMode:"Неподдържан режим на нотификациите. Използвайте някой от поддържаните режими 'auto', 'popover', 'inline'."};$.ig.Notifier.locale=$.ig.Notifier.locale||$.ig.locale.bg.Notifier;return $.ig.locale.bg.Notifier});