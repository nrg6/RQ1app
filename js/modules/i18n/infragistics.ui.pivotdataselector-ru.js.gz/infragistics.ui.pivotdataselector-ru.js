/*!@license
* Infragistics.Web.ClientUI Pivot Data Selector localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.PivotDataSelector=$.ig.PivotDataSelector||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ru=$.ig.locale.ru||{};$.ig.locale.ru.PivotDataSelector={invalidBaseElement:" не может быть использован в качестве базового элемента. Вместо этого используйте DIV.",catalog:"Каталог",cube:"Куб",measureGroup:"Группа Мер",measureGroupAll:"(Все)",rows:"Ряды",columns:"Колонки",measures:"Меры",filters:"Фильтры",deferUpdate:"Задержать Обновление",updateLayout:"Обновить Раскладку",selectAll:"Выбрать Все"};$.ig.PivotDataSelector.locale=$.ig.PivotDataSelector.locale||$.ig.locale.ru.PivotDataSelector;return $.ig.locale.ru.PivotDataSelector});