/*!@license
* Infragistics.Web.ClientUI Pivot Data Selector localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.PivotDataSelector=$.ig.PivotDataSelector||{};$.ig.locale=$.ig.locale||{};$.ig.locale.bg=$.ig.locale.bg||{};$.ig.locale.bg.PivotDataSelector={invalidBaseElement:" не се поддържа като основен елемент. Използвай DIV вместо това.",catalog:"Каталог",cube:"Куб",measureGroup:"Група от мерки",measureGroupAll:"(Всичко)",rows:"Редове",columns:"Колони",measures:"Мерки",filters:"Филтри",deferUpdate:"Отложи актуализацията",updateLayout:"Актуализирай оформлението",selectAll:"Избери всичко"};$.ig.PivotDataSelector.locale=$.ig.PivotDataSelector.locale||$.ig.locale.bg.PivotDataSelector;return $.ig.locale.bg.PivotDataSelector});