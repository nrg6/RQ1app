/*!@license
* Infragistics.Web.ClientUI Popover localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ru=$.ig.locale.ru||{};$.ig.Popover=$.ig.Popover||{};$.ig.locale.ru.Popover={popoverOptionChangeNotSupported:"Изменение этой опции невозможно после инициализации igPopover:",popoverShowMethodWithoutTarget:"Параметр target функции show обязателен, когда используется опция selectors"};$.ig.Popover.locale=$.ig.Popover.locale||$.ig.locale.ru.Popover;return $.ig.locale.ru.Popover});