/*!@license
* Infragistics.Web.ClientUI Toolbar localization resources 24.1.9
*
* Copyright (c) 2011-2024 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.Toolbar=$.ig.Toolbar||{};$.ig.locale=$.ig.locale||{};$.ig.locale.fr=$.ig.locale.fr||{};$.ig.locale.fr.Toolbar={collapseButtonTitle:"Réduire {0}",expandButtonTitle:"Etendre {0}"};$.ig.Toolbar.locale=$.ig.Toolbar.locale||$.ig.locale.fr.Toolbar;return $.ig.locale.fr.Toolbar});